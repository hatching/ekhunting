from mitmproxy.console import master


__all__ = ["master"]
