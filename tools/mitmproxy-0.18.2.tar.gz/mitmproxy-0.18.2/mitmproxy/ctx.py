from typing import Callable  # noqa

master = None  # type: "mitmproxy.flow.FlowMaster"
log = None  # type: "mitmproxy.controller.Log"
