from __future__ import (absolute_import, print_function, division)

IVERSION = (0, 18, 2)
VERSION = ".".join(str(i) for i in IVERSION)
PATHOD = "pathod " + VERSION
MITMPROXY = "mitmproxy " + VERSION
